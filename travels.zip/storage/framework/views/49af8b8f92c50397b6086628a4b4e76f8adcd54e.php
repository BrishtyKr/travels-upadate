<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 info@travel24 </b>All rights reserved.
            </div>
</div><?php /**PATH C:\laragon\www\travels\resources\views/shared/admin/admin_footer.blade.php ENDPATH**/ ?>