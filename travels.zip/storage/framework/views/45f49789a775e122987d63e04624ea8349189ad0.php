
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?> || Travello</title>
    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">  <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="<?php echo e(asset('public/asset/')); ?>/font-awesome-4.7.0/css/font-awesome.min.css">                <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('public/asset/')); ?>/css/bootstrap.min.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/asset/')); ?>/slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/asset/')); ?>/slick/slick-theme.css"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/asset/')); ?>/css/datepicker.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('public/asset/')); ?>/css/tooplate-style.css">                                   <!-- Templatemo style -->
</head>

    <body>
        <div class="tm-main-content" id="top">
            <div class="tm-top-bar-bg"></div>
            <div class="tm-top-bar" id="tm-top-bar">
                <!-- Top Navbar -->
                <div class="container">
                    <div class="row">
                        
                        <?php echo $__env->make('shared.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                  
                    </div>
                </div>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('shared.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <!-- load JS files -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        
        <script src="<?php echo e(asset('public/asset/')); ?>/js/popper.min.js"></script>                    <!-- https://popper.js.org/ -->       
        <script src="<?php echo e(asset('public/asset/')); ?>/js/bootstrap.min.js"></script>                 <!-- https://getbootstrap.com/ -->
        <script src="<?php echo e(asset('public/asset/')); ?>/js/datepicker.min.js"></script>                <!-- https://github.com/qodesmith/datepicker -->
        <script src="<?php echo e(asset('public/asset/')); ?>/js/jquery.singlePageNav.min.js"></script>      <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
        <script src="<?php echo e(asset('public/asset/')); ?>/slick/slick.min.js"></script>                  <!-- http://kenwheeler.github.io/slick/ -->
        <script src="<?php echo e(asset('public/asset/')); ?>/custom.js"></script>             
        <?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\travels\resources\views/layouts/main.blade.php ENDPATH**/ ?>