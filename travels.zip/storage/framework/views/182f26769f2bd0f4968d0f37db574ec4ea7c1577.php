
<?php $__env->startSection('title','Car'); ?>
<?php $__env->startSection('content'); ?>
    <div class="tm-section tm-bg-img" id="tm-section-1" style="background-image:url(<?php echo e(asset('public/asset/img/39.jpg')); ?>)">
                <div class="tm-bg-white ie-container-width-fix-2">
                    <div class="container ie-h-align-center-fix">
                        <div class="row">
                            <div class="col-xs-12 ml-auto mr-auto ie-container-width-fix">
                                <h1 class="p-3">Car List</h1>
                            </div>                        
                        </div>      
                    </div>
                </div>                  
            </div>
            
            <div class="tm-section-2 pb-3">
                <div class="container">
                    <div class="row">
                        <div class="col text-center">
                            <h2 class="tm-section-title">We are here to help you?</h2>
                            <p class="tm-color-white tm-section-subtitle">Subscribe to get our newsletters</p>
                            <a href="#" class="tm-color-white tm-btn-white-bordered">Subscribe Newletters</a>
                        </div>                
                    </div>
                </div>        
            </div>
            <div class="tm-bg-video">
                <div class="tm-section tm-section-pad tm-bg-img" id="tm-section-5">                                                        
                    <div class="container ie-h-align-center-fix">
                        <div class="row tm-flex-align-center">
                            <div class="col-xs-12 col-md-12 col-lg-3 col-xl-3 tm-media-title-container">
                                <h2 class="text-uppercase tm-section-title-2">Car</h2>
                                <h3 class="tm-color-primary tm-font-semibold tm-section-subtitle-2">List</h3>
                            </div>
                            <div class="col-xs-12 col-md-12 col-lg-9 col-xl-9 mt-0 mt-sm-3">
                                <div class="ml-auto tm-bg-white-shadow tm-pad tm-media-container">
                                    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <article class="media tm-margin-b-20 tm-media-1">
                                        <img src="<?php echo e(asset('public/uploads/carImages/'.$item->image)); ?>" style="
    width: 372px;
    height: 200px;
" alt="Image">
                                        <div class="media-body tm-media-body-1 tm-media-body-v-center">
                                            <h3 class="tm-font-semibold tm-color-primary tm-article-title-3"><?php echo e($item->name); ?></h3>
                                            <p><span class="text-success">Model: </span> <?php echo e($item->model); ?>

                                            <br><span class="text-danger">Rent: </span> <?php echo e($item->rent); ?> TK.<br>
											<span class="text-success">No. Of Seats: </span><?php echo e($item->no_of_seats); ?></p>
                                        </div>                                
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travels\resources\views/car.blade.php ENDPATH**/ ?>