
<?php $__env->startSection('title'); ?>
    Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="module">
        <div class="module-option clearfix">
            <div class="pull-left">
                Add Blog
            </div>
            <div class="pull-right">
                <a href="<?php echo e(action('Admin\BlogController@create')); ?>" class="btn btn-primary">Add Blog</a>
            </div>
        </div>
    </div>
    <div class="module">
        <div class="module-head">
            <h3>
                All Blogs</h3>
        </div>
        <div class="module-body table">
            <table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display"
                   width="100%">
                <thead>
                <tr>
                    <th>S/N</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th style="text-align:right;">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                        $i=1
                    ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX">
                            <td><?php echo e($i++); ?></td>
                            <td><?php if($item->image == 'default.jpg'): ?>
                                <img width="50" height="30" src="<?php echo e(asset('public/image/default.jpg')); ?>" alt="">
                            <?php else: ?>
                              <img width="50" height="30" src="<?php echo e(asset('public/uploads/blogImages/'.$item->image)); ?>" alt="">
                            <?php endif; ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td>1</td>
                            <td><?php echo e(\Illuminate\Support\Str::limit($item->description,50,'...')); ?></td>
                            <td style="text-align:right;">
                                <a class="btn btn-success btn-xs" href="<?php echo e(action('Admin\BlogController@update_page',['id'=> $item->id])); ?>"><i class="icon-edit"></i></a>
                                <a onclick="return confirm('Are you sure to delete?')" class="btn btn-danger btn-xs" href="<?php echo e(action('Admin\BlogController@delete',['id'=> $item->id])); ?>"><i class="icon-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\travels\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>