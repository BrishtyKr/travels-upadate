@extends('layouts.master_admin')
@section('title')
    Dashboard
@endsection