<div class="footer">
            <div class="container">
                <b class="copyright">&copy; 2019 info@travel24 </b>All rights reserved.
            </div>
</div>